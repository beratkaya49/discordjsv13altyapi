const { Client, Intents, Collection } = require('discord.js');
const ayarlar = require('./ayarlar.json');
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v9');
const client = new Client({
  intents: [
    Intents.FLAGS.GUILDS,
    Intents.FLAGS.GUILD_MESSAGES,
    Intents.FLAGS.GUILD_MEMBERS,
    Intents.FLAGS.DIRECT_MESSAGES
    ]
  });

['commandHandler', 'eventHandler', 'slashCommandHandler'].forEach(handler => {
  require(`./handlers/${handler}`)(client);
});

client.on('messageCreate', (message) => {
    // Botun kendi mesajlarına cevap vermemesi için kontrol
    if (message.author.bot) return;

    if (message.content.toLowerCase() === 'sa') {
        message.reply('Aleyküm Selam Hoş geldin!');
    }
});

client.on('messageCreate', (message) => {
    // Botun kendi mesajlarına cevap vermemesi için kontrol
    if (message.author.bot) return;

    if (message.content.toLowerCase() === 'Sa') {
        message.reply('Aleyküm Selam Hoş geldin!');
    }
});

client.login(ayarlar.token)



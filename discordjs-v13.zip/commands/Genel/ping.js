module.exports = {
  name: 'ping',
  async execute(message) {
    message.reply('Pong!')
    }
}
